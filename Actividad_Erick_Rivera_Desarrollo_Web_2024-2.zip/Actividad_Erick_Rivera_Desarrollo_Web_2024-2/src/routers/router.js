const express = require('express');
const router = express.Router();
const crudController = require('../controllers/crud');

// Ruta para obtener todos los registros
router.get('/', crudController.getAllRecords);

// Ruta para mostrar el formulario de creación
router.get('/create', (req, res) => {
    res.render('create'); // 
});

// Ruta para guardar un nuevo registro
router.post('/create', crudController.createRecord);

// Ruta para mostrar el formulario de edición
router.get('/edit/:id', crudController.editForm);

// Ruta para guardar un registro editado
router.post('/edit/:id', crudController.saveUpdatedRecord);

// Ruta para visualizar un registro específico
router.get('/view/:id', crudController.viewRecord);

// Ruta para eliminar un registro
router.post('/delete/:id', crudController.deleteRecord);

// Exportar el router
module.exports = router;
