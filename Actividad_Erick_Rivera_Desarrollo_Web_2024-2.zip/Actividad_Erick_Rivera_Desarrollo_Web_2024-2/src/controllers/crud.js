const connection = require('../database/db');

// Renderizar todos los registros en index.ejs
exports.getAllRecords = (req, res) => {
    connection.query('SELECT * FROM registros', (err, results) => {
        if (err) {
            console.error('Error al obtener los registros:', err);
            return res.status(500).send('Error al obtener los registros');
        }
        res.render('index', { records: results });
    });
};

// Renderizar el formulario de edición con datos del registro
exports.editForm = (req, res) => {
    const id = req.params.id;
    connection.query('SELECT * FROM registros WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error('Error al obtener el registro:', err);
            return res.status(500).send('Error al obtener el registro');
        }
        res.render('edit', { record: results[0] });
    });
};

// Crear un nuevo registro
exports.createRecord = (req, res) => {
    const { nombre, apellido, rol, telefono, correo, edad } = req.body;
    const query = 'INSERT INTO registros (nombre, apellido, rol, telefono, correo, edad) VALUES (?, ?, ?, ?, ?, ?)';

    connection.query(query, [nombre, apellido, rol, telefono, correo, edad], (err, result) => {
        if (err) {
            console.error('Error al guardar el registro:', err);
            return res.status(500).send('Error al guardar el registro');
        }
        res.redirect('/'); // Redirige al menú principal después de guardar
    });
};

// Guardar un registro modificado
exports.saveUpdatedRecord = (req, res) => {
    const id = req.params.id;
    const { nombre, apellido, rol, telefono, correo, edad } = req.body;
    const query = 'UPDATE registros SET nombre = ?, apellido = ?, rol = ?, telefono = ?, correo = ?, edad = ? WHERE id = ?';

    connection.query(query, [nombre, apellido, rol, telefono, correo, edad, id], (err, result) => {
        if (err) {
            console.error('Error al actualizar el registro:', err);
            return res.status(500).send('Error al actualizar el registro');
        }
        res.redirect('/'); // Redirige a la lista después de actualizar
    });
};

// Buscar un registro por ID
exports.searchRecord = (req, res) => {
    const id = req.query.id;
    connection.query('SELECT * FROM registros WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error('Error al buscar el registro:', err);
            return res.status(500).send('Error al buscar el registro');
        }
        res.render('index', { records: results });
    });
};

// Visualizar un registro específico
exports.viewRecord = (req, res) => {
    const id = req.params.id;
    connection.query('SELECT * FROM registros WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error('Error al obtener el registro:', err);
            return res.status(500).send('Error al obtener el registro');
        }
        res.render('visualizar', { record: results[0] });
    });
};

// Eliminar un registro
exports.deleteRecord = (req, res) => {
    const id = req.params.id;
    connection.query('DELETE FROM registros WHERE id = ?', [id], (err, result) => {
        if (err) {
            console.error('Error al eliminar el registro:', err);
            return res.status(500).send('Error al eliminar el registro');
        }
        res.redirect('/'); // Redirige a la lista después de eliminar
    });
};
