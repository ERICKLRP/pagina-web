const express = require('express');
const path = require('path');
const app = express();
const router = require('./routers/router'); // Importa el enrutador

// Configuración del servidor
app.use(express.json()); // Para manejar datos JSON
app.use(express.urlencoded({ extended: false })); // Para manejar datos enviados en formularios

// Configuración para servir archivos estáticos desde la carpeta styles
app.use('/styles', express.static(path.join(__dirname, 'styles')));

// Configuración del motor de vistas
app.set('view engine', 'ejs'); // Define EJS como motor de vistas
app.set('views', path.join(__dirname, 'views')); // Establece la ruta de las vistas

// Configuración de rutas
app.use('/', router); // Usa el enrutador principal

// Inicio del servidor
app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});

module.exports = app; // Exporta para posibles pruebas
